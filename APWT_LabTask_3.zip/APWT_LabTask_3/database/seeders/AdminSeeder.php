<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Admin::factory()->create([
            'name'=> 'Teacher 1',
            'username'=> 'abc1233',
            'email'=> 'another@email.com',
            'dob'=> '6/1/2000',
            
            'phone'=> '1234',
            'password'=> '1234',
        ]);
    }
}

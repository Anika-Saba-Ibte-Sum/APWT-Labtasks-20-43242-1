
<?php $__env->startSection('content'); ?>
<img src="images/car.jpg" width="1120" height="500">

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\APWT_LabTask_3\resources\views/home.blade.php ENDPATH**/ ?>
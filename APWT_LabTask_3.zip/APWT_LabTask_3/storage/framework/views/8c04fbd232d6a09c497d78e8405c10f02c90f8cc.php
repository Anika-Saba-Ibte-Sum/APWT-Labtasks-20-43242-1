
<?php $__env->startSection('content'); ?>
<br><h1 >Login</h1><br>
<form action="<?php echo e(route('login')); ?>" class="form-group " method="post">
    <!-- Cross Site Request Forgery-->
    <?php echo e(csrf_field()); ?>

    
    <div class="col-md-4 form-group">
        <span>Username</span>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control">
        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4 form-group">
        <span>Password</span>
        <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <br>
    <input type="submit" class="btn btn-success" value="Sign In" href="<?php echo e(route('adminDash')); ?>" >  
    <a class="btn btn-primary" href="<?php echo e(route('registration')); ?>">Sign Up</a>                 
</form>


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\APWT_LabTask_3\resources\views/login.blade.php ENDPATH**/ ?>
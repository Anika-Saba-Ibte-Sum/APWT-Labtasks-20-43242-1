<html>
    <a class="collapse navbar-collapse" id="navbarSupportedContent" href="<?php echo e(route('registration')); ?>">Sign Up</a>
    <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Log In</a>
    <a class="btn btn-primary" href="<?php echo e(route('registerList')); ?>">Register List</a>
    

</html><?php /**PATH C:\xampp\htdocs\APWT_TASK_2\resources\views/inc/navbar.blade.php ENDPATH**/ ?>
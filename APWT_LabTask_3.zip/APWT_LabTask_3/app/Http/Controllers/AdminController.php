<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Http\Requests\StoreAdminRequest;
use App\Http\Requests\UpdateAdminRequest;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreAdminRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAdminRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function show(Admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateAdminRequest  $request
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateAdminRequest $request, Admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(Admin $admin)
    {
        //
    }

    public function adminCreate(){
        return view('admin.adminCreate');
    }
    public function adminCreateSubmitted(Request $request){
        $admin = new Admin();
        $admin->name= $request->name;
        $admin->username= $request->username;
        $admin->email= $request->email;
        $admin->dob= $request->dob;
        
        $admin->phone= $request->phone;
        $admin->password= $request->password;
        $admin->save();
        return redirect()->route('sellerList');
    }
    public function sellerList(){
        $admins = Admin::all();
        return view('admin.sellerList')->with('admins', $admins);
    }
    public function adminSellers(){

        $a = Admin::where('id',1)->first();
        // return $t->id;
        //hasmany
        return $t->sellers;

        //eloquent
        // return $t->assignedCourses();
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Admin;

class LoginController extends Controller
{
    public function Login(){
        return view('admin.login');
    }
    public function loginSubmit(Request $request){
        $admin = Admin::where('username',$request->username)
                            ->where('password',$request->password)
                            ->first();

        // return $teacher;
        if($admin){
            $request->session()->put('user',$teacher->name);
            return redirect()->route('adminDash');
        }
        return back();
    }
    public function logout(){
        session()->forget('user');
        return redirect()->route('login');
    }
}

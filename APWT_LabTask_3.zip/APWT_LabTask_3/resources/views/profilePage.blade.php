@extends('layouts.app')
@section('content')

    @if(Session::get('user')) {{Session::get('user')}} 
    <br>
    <h1>Profile Details</h1>
    @endif 
@endsection 
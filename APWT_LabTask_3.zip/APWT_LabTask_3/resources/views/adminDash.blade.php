@extends('layouts.app')
@section('content')

    @if(Session::get('user')) {{Session::get('user')}} 
    <br>
    <a class="btn btn-danger" href="{{route('logout')}}">Log out </a>
    <a class="btn btn-danger" href="{{route('profilePage')}}">Profile Page </a>
    <a class="btn btn-danger" href="{{route('userEdit')}}">User Edit </a>
    <a class="btn btn-danger" href="{{route('registerList')}}">Register List </a>
    @endif 
@endsection 
@extends('layouts.app')
@section('content')
<img src="images/car.jpg" width="1120" height="500">

@endsection 